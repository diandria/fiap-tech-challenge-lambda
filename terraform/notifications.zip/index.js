"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handler.ts
var handler_exports = {};
__export(handler_exports, {
  createHandler: () => createHandler,
  handler: () => handler
});
module.exports = __toCommonJS(handler_exports);

// src/event.ts
var KNOWN_TYPES = ["SERVICE_ORDER_STATUS_CHANGED", "BUDGET_READY"];
function parseEvent(raw) {
  let value;
  try {
    value = JSON.parse(raw);
  } catch {
    return null;
  }
  const event = value;
  if (!event || typeof event !== "object") return null;
  if (!KNOWN_TYPES.includes(event.eventType)) return null;
  if (!event.serviceOrder?.id || !event.serviceOrder?.status) return null;
  if (!event.customer?.email || !event.customer?.name) return null;
  return event;
}

// src/messageBuilder.ts
var asCurrency = (value) => new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL"
}).format(value);
function statusMessage(event) {
  return {
    subject: `Sua ordem de servi\xE7o foi atualizada`,
    body: [
      `Ol\xE1, ${event.customer.name}.`,
      ``,
      `A ordem de servi\xE7o ${event.serviceOrder.id} mudou de situa\xE7\xE3o.`,
      `Situa\xE7\xE3o atual: ${event.serviceOrder.status}`,
      ``,
      `Equipe da oficina`
    ].join("\n")
  };
}
function budgetMessage(event) {
  const total = event.serviceOrder.budgetTotal;
  const amountLine = typeof total === "number" && Number.isFinite(total) ? `Valor total: ${asCurrency(total)}` : `O valor ser\xE1 informado pela oficina.`;
  return {
    subject: `O or\xE7amento da sua ordem de servi\xE7o est\xE1 pronto`,
    body: [
      `Ol\xE1, ${event.customer.name}.`,
      ``,
      `O or\xE7amento da ordem de servi\xE7o ${event.serviceOrder.id} est\xE1 pronto.`,
      amountLine,
      ``,
      `Acesse o sistema para aprovar ou recusar.`,
      ``,
      `Equipe da oficina`
    ].join("\n")
  };
}
function buildMessage(event) {
  const content = event.eventType === "BUDGET_READY" ? budgetMessage(event) : statusMessage(event);
  return { to: event.customer.email, ...content };
}

// src/deliveryChannel.ts
var LoggingDeliveryChannel = class {
  async send(event) {
    const message = buildMessage(event);
    console.info(
      JSON.stringify({
        level: "info",
        msg: "notificacao entregue",
        service_name: "car-repair-shop-notifications",
        event_type: event.eventType,
        service_order_id: event.serviceOrder.id,
        to: message.to,
        subject: message.subject,
        body: message.body
      })
    );
  }
};

// src/handler.ts
function createHandler(channel) {
  return async function handler2(event) {
    const parsed = event.Records.map((record) => {
      const result = parseEvent(record.Sns.Message);
      if (!result) {
        console.warn(
          JSON.stringify({
            level: "warn",
            msg: "evento descartado: payload invalido ou tipo desconhecido",
            service_name: "car-repair-shop-notifications"
          })
        );
      }
      return result;
    }).filter((e) => e !== null);
    for (const item of parsed) {
      await channel.send(item);
    }
  };
}
var handler = createHandler(new LoggingDeliveryChannel());
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createHandler,
  handler
});
